const std = @import("std");
const builtin = @import("builtin");
const assert = std.debug.assert;
const c = @import("c.zig").c;
const objc = @import("main.zig");

/// Returns a struct that implements the msgSend function for type T.
pub fn MsgSend(comptime T: type) type {
    // 1. T should be a struct
    // 2. T should have a field "value" that can be an "id" (same size)

    return struct {
        /// Invoke a selector on the target, i.e. an instance method on an
        /// object or a class method on a class. The args should be a tuple.
        pub fn msgSend(
            target: T,
            comptime Return: type,
            sel_raw: anytype,
            args: anytype,
        ) Return {
            // Our one special-case: If the return type is our own Object
            // type then we wrap it.
            const is_object = Return == objc.Object;

            // Our actual return value is an "id" if we are using one of
            // our built-in types (see above). Otherwise, we trust the caller.
            const RealReturn = if (is_object) c.id else Return;

            // We accept multiple types for sel but we need to turn it into
            // an objc.sel ultimately.
            const sel: objc.Sel = switch (@TypeOf(sel_raw)) {
                objc.Sel => sel_raw,
                else => objc.sel(sel_raw),
            };

            // Build our function type and call it
            const Fn = MsgSendFn(RealReturn, @TypeOf(target.value), @TypeOf(args));
            const msg_send_fn = comptime msgSendPtr(RealReturn, false);
            const msg_send_ptr: *const Fn = @ptrCast(@alignCast(msg_send_fn));

            // Unwrap any Object types in args to their underlying c.id
            const unwrapped_args = buildUnwrappedArgs(args);
            const result = @call(.auto, msg_send_ptr, .{ target.value, sel.value } ++ unwrapped_args);

            if (!is_object) return result;
            return .{ .value = result };
        }

        /// Invoke a selector on the superclass.
        pub fn msgSendSuper(
            target: T,
            superclass: objc.Class,
            comptime Return: type,
            sel_raw: anytype,
            args: anytype,
        ) Return {
            // See msgSend for in depth comments on all of this. This is
            // effectively the same logic.
            const is_object = Return == objc.Object;
            const RealReturn = if (is_object) c.id else Return;
            const sel: objc.Sel = switch (@TypeOf(sel_raw)) {
                objc.Sel => sel_raw,
                else => objc.sel(sel_raw),
            };

            const Fn = MsgSendFn(RealReturn, *c.objc_super, @TypeOf(args));
            const msg_send_fn = comptime msgSendPtr(RealReturn, true);
            const msg_send_ptr: *const Fn = @ptrCast(@alignCast(msg_send_fn));
            var super: c.objc_super =
                if (comptime @hasField(c.objc_super, "super_class"))
                    .{
                        .receiver = target.value,
                        .super_class = superclass.value,
                    }
                else
                    .{
                        .receiver = target.value,
                        .class = superclass.value,
                    };

            // Unwrap any Object types in args to their underlying c.id
            const unwrapped_args = buildUnwrappedArgs(args);
            const result = @call(.auto, msg_send_ptr, .{ &super, sel.value } ++ unwrapped_args);

            if (!is_object) return result;
            return .{ .value = result };
        }

        /// Returns the objc_msgSend or objc_msgSendSuper pointer for the
        /// given return type.
        fn msgSendPtr(
            comptime Return: type,
            comptime super: bool,
        ) *const fn () callconv(.c) void {
            // See objc/message.h. The high-level is that depending on the
            // target architecture and return type, we must use a different
            // objc_msgSend function.
            return switch (builtin.target.cpu.arch) {
                // Aarch64 uses objc_msgSend for everything. Hurray!
                .aarch64 => if (super) &c.objc_msgSendSuper else &c.objc_msgSend,

                // x86_64 depends on the return type...
                .x86_64 => switch (@typeInfo(Return)) {
                    // Most types use objc_msgSend
                    inline .int,
                    .bool,
                    .@"enum",
                    .pointer,
                    .void,
                    => if (super) &c.objc_msgSendSuper else &c.objc_msgSend,

                    .optional => |opt| opt: {
                        assert(@typeInfo(opt.child) == .pointer);
                        break :opt if (super) &c.objc_msgSendSuper else &c.objc_msgSend;
                    },

                    // Structs must use objc_msgSend_stret.
                    // NOTE: This is probably WAY more complicated... we only
                    // call this if the struct is NOT returned as a register.
                    // And that depends on the size of the struct. But I don't
                    // know what the breakpoint actually is for that. This SO
                    // answer says 16 bytes so I'm going to use that but I have
                    // no idea...
                    .@"struct" => blk: {
                        if (@sizeOf(Return) > 16) {
                            break :blk if (super)
                                &c.objc_msgSendSuper_stret
                            else
                                &c.objc_msgSend_stret;
                        } else {
                            break :blk if (super)
                                &c.objc_msgSendSuper
                            else
                                &c.objc_msgSend;
                        }
                    },

                    // Floats use objc_msgSend_fpret for f64 on x86_64,
                    // but normal msgSend for other bit sizes. i386 has
                    // more complex rules but we don't support i386 at the time
                    // of this comment and probably never will since all i386
                    // Apple models are discontinued at this point.
                    .float => |float| switch (float.bits) {
                        64 => if (super) &c.objc_msgSendSuper_fpret else &c.objc_msgSend_fpret,
                        else => if (super) &c.objc_msgSendSuper else &c.objc_msgSend,
                    },

                    // Otherwise we log in case we need to add a new case above
                    else => {
                        @compileLog(@typeInfo(Return));
                        @compileError("unsupported return type for objc runtime on x86_64");
                    },
                },

                else => @compileError("unsupported objc architecture"),
            };
        }
    };
}

/// This returns a function body type for `obj_msgSend` that matches
/// the given return type, target type, and arguments tuple type.
///
/// obj_msgSend is a really interesting function, because it doesn't act
/// like a typical function. You have to call it with the C ABI as if you're
/// calling the true target function, not as a varargs C function. Therefore
/// you have to cast obj_msgSend to a function pointer type of the final
/// destination function, then call that.
///
/// Example: you have an ObjC function like this:
///
///     @implementation Foo
///     - (void)log: (float)x { /* stuff */ }
///
/// If you call it like this, it won't work (you'll get garbage):
///
///     objc_msgSend(obj, @selector(log:), (float)PI);
///
/// You have to call it like this:
///
///     ((void (*)(id, SEL, float))objc_msgSend)(obj, @selector(log:), M_PI);
///
/// This comptime function returns the function body type that can be used
/// to cast and call for the proper C ABI behavior.
fn MsgSendFn(
    comptime Return: type,
    comptime Target: type,
    comptime Args: type,
) type {
    const argsInfo = @typeInfo(Args).@"struct";
    assert(argsInfo.is_tuple);

    // Target must always be an "id". Lots of types (Class, Object, etc.)
    // are an "id" so we just make sure the sizes match for ABI reasons.
    assert(@sizeOf(Target) == @sizeOf(c.id));

    // Build up our argument types for @Fn
    var param_types: [argsInfo.fields.len + 2]type = undefined;
    param_types[0] = Target;
    param_types[1] = c.SEL;
    for (argsInfo.fields, 0..) |field, i| param_types[i + 2] = unwrapType(field.type);

    return @Fn(&param_types, &@splat(.{}), Return, .{ .@"callconv" = .c });
}

fn UnwrappedArgs(comptime Args: type) type {
    const fields = @typeInfo(Args).@"struct".fields;
    var types: [fields.len]type = undefined;
    for (fields, 0..) |field, i| types[i] = unwrapType(field.type);
    return @Tuple(&types);
}

/// Maps objc wrapper types to their underlying C types for use in @Fn signatures,
/// and validates that all other types are C-ABI compatible.
fn unwrapType(comptime T: type) type {
    // Unwrap our objc.Object type
    if (T == objc.Object) return c.id;

    // Unwrap any other objc wrapper (Class, Sel, etc.) — identified by having
    // a single 'value' field of pointer size. Return the actual field type
    // rather than c.id, since Class and Sel have distinct pointer types.
    if (@typeInfo(T) == .@"struct") {
        const info = @typeInfo(T).@"struct";
        for (info.fields) |field| {
            if (std.mem.eql(u8, field.name, "value") and @sizeOf(field.type) == @sizeOf(c.id)) {
                return field.type;
            }
        }
    }

    // Validate that the remaining type is safe to pass over the C ABI.
    // Previously (pre-0.16), passing a non-C-compatible type like []const u8
    // would silently compile but segfault at runtime via objc_msgSend.
    // These checks turn that into a compile error.
    switch (@typeInfo(T)) {
        .int, .float, .bool, .void => {},
        .@"enum" => {},
        .pointer => {},
        .optional => |opt| {
            if (@typeInfo(opt.child) != .pointer)
                @compileError("msgSend: " ++ @typeName(T) ++ " — optional must wrap a pointer");
        },
        .@"struct" => |s| {
            if (s.layout != .@"extern" and s.layout != .@"packed")
                @compileError("msgSend: " ++ @typeName(T) ++ " — struct must be extern or packed");
        },
        .@"union" => |u| {
            if (u.layout != .@"extern")
                @compileError("msgSend: " ++ @typeName(T) ++ " — union must be extern");
        },
        else => @compileError("msgSend: " ++ @typeName(T) ++ " — not C-ABI compatible"),
    }

    return T;
}

inline fn buildUnwrappedArgs(args: anytype) UnwrappedArgs(@TypeOf(args)) {
    const fields = @typeInfo(@TypeOf(args)).@"struct".fields;
    var result: UnwrappedArgs(@TypeOf(args)) = undefined;
    inline for (fields, 0..) |_, i| {
        result[i] = if (unwrapType(@TypeOf(args[i])) != @TypeOf(args[i]))
            args[i].value
        else
            args[i];
    }
    return result;
}

test {
    const testing = std.testing;
    try testing.expectEqual(fn (
        c.id,
        c.SEL,
    ) callconv(.c) u64, MsgSendFn(u64, c.id, @TypeOf(.{})));
    try testing.expectEqual(fn (c.id, c.SEL, u16, u32) callconv(.c) u64, MsgSendFn(u64, c.id, @TypeOf(.{
        @as(u16, 0),
        @as(u32, 0),
    })));
}

test "subClass" {
    const Subclass = objc.allocateClassPair(objc.getClass("NSObject").?, "subclass").?;
    defer objc.disposeClassPair(Subclass);
    const str = struct {
        fn inner(target: objc.c.id, sel: objc.c.SEL) callconv(.c) objc.c.id {
            _ = sel;
            const self = objc.Object.fromId(target);
            self.msgSendSuper(objc.getClass("NSObject").?, void, "init", .{});
            return target;
        }
    };
    Subclass.replaceMethod("init", str.inner);
    objc.registerClassPair(Subclass);
    const subclass_obj = Subclass.msgSend(objc.Object, "alloc", .{});
    defer subclass_obj.msgSend(void, "dealloc", .{});
    subclass_obj.msgSend(void, "init", .{});
}
