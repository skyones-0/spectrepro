enum E {
  unavailable __attribute__((unavailable)) = 0,
  oldval __attribute__((deprecated)),
  newval
};

void foo(void) {
    int a __attribute__((noreturn));
    int b __attribute__((does_not_exist(4)));
    int c __attribute__((aligned(16)));
    int d __attribute__((aligned(4 + 4 + 4 + 4)));

    int e __attribute__((aligned(4)));
    int __attribute__((aligned(4))) f;
    __attribute__((aligned(4))) int g;

    __attribute__(()) int h;
    __attribute__((aligned(4), unused)) int i;
    __attribute__((aligned(4), unused, uninitialized)) int j;
    __attribute__((mode(__byte__))) int k;

    __attribute__((section("mysegment,mysection"))) static int l;
}

int bar(void) {
Label:
    __attribute__((deprecated));
    return 0;

ErrorHandling:
    __attribute__((__hot__, cold(), __unused__()));
    return 1;
}

void bad_fallthrough(void) {
    __attribute__((fallthrough));
}

void invalid_statement_attribute(void) {
    __attribute__((noreturn));
}

void qux(int x) {
    switch (x) {
        case 1:
            bar();
            __attribute__((fallthrough));
        case 2:
            __attribute__((fallthrough));
        default:
            return;
    }
}

__attribute__((format(printf, 2, 3))) __attribute__((noreturn)) void my_printf (void *my_object, const char *my_format, ...);
__attribute__((noreturn, format(printf, 2, 3), hot)) void my_printf1 (void *my_object, const char *my_format, ...);
__attribute__((format(printf, 2, 3))) void my_printf2 (void *my_object, const char *my_format, ...);
__attribute__((format(printf, 2, 3), noreturn)) void my_printf3 (void *my_object, const char *my_format, ...);

struct S1 { int x; } __attribute__ ((aligned (8)));
struct __attribute__ ((aligned (8))) S2 { int x; };
union U1 { int x; int y; } __attribute__ ((aligned (8)));
union __attribute__ ((aligned (8))) U2 { int x; int y; };
enum E1 { FOO } __attribute__ ((aligned (8)));
enum __attribute__ ((aligned (8))) E2 { BAR };

void vectors(void) {
    __attribute__ ((vector_size (32))) typedef __attribute__ ((aligned (32))) int int_vec32_t0;
    typedef __attribute__ ((vector_size (32))) int int_vec32_t1;
    typedef int __attribute__ ((vector_size (32))) int_vec32_t2;
    typedef int int_vec32_t3 __attribute__ ((vector_size (32)));
}

void diagnostics(void) {
    int __attribute__((aligned(4))) x;
    x(0);
}

void math(void) {
    int __attribute__((aligned(4))) x = 0;
    (void) (x / 2);
}

extern int abs (int __x) __attribute__((__noreturn__ )) __attribute__((__const__));

typedef int X();
X x __attribute__((cold));

typedef struct {
  __attribute__((__aligned__(__alignof__(long long)))) long long __clang_max_align_nonce1, __attribute__((packed)) nonce2, nonce3;
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;

__attribute__((unused)) void attributed_old_style_func(baz)
int baz;
{
}

_Static_assert(sizeof(struct S2) == 8, "sizeof aligned struct");
_Static_assert(_Alignof(union U1) == 8, "_Alignof aligned union");

typedef struct {
    short i:1 __attribute__((aligned(8)));
} A;

__attribute__((aligned(32))) char aligned_arr[] = {1, 2, 3};
_Static_assert(sizeof(aligned_arr) == 3, "");

__attribute__((section(1))) int Z;

__attribute__((void)) int a;

int (__attribute__((aligned)) a);

[[deprecated("foo")]] int c23_extension;

void gnu_label_attribute(int x) {
    foo:
    __attribute__((unused, hot))
    int a;
}

__attribute__((fallthrough)) int fallthrough_on_decl;

__attribute__(()) // test attribute at eof

/** manifest:
syntax
args = -Wno-deprecated-non-prototype -Wc23-extensions -std=gnu17
skip = TODO: implement 'mode' attribute
skip = TODO: implement 'format' attribute

attributes.c:8:26: warning: 'noreturn' attribute only applies to functions [-Wignored-attributes]
attributes.c:9:26: warning: unknown attribute 'does_not_exist' ignored [-Wunknown-attributes]
attributes.c:19:40: warning: unknown attribute 'uninitialized' ignored [-Wunknown-attributes]
attributes.c:20:20: warning: TODO: implement 'mode' attribute
attributes.c:22:20: warning: 'section' attribute only applies to functions and global variables [-Wignored-attributes]
attributes.c:27:20: error: 'deprecated' attribute cannot be applied to a statement
attributes.c:31:29: error: 'cold' and 'hot' attributes are not compatible
attributes.c:31:20: note: conflicting attribute is here
attributes.c:36:20: error: 'fallthrough' attribute outside a switch statement
attributes.c:40:20: error: 'noreturn' attribute cannot be applied to a statement
attributes.c:55:16: warning: TODO: implement 'format' attribute
attributes.c:56:26: warning: TODO: implement 'format' attribute
attributes.c:57:16: warning: TODO: implement 'format' attribute
attributes.c:58:16: warning: TODO: implement 'format' attribute
attributes.c:76:6: error: cannot call non function type 'int'
attributes.c:110:24: error: expected a string as argmuent of 'section' attribute but got an integer constant
attributes.c:112:16: warning: unknown attribute 'void' ignored [-Wunknown-attributes]
attributes.c:116:1: warning: [[]] attributes are a C23 extension [-Wc23-extensions]
attributes.c:121:5: warning: label followed by a declaration is a C23 extension [-Wc23-extensions]
attributes.c:120:5: warning: GNU-style attribute between label and declaration applies to the label [-Wlabel-attribute]
attributes.c:124:16: error: 'fallthrough' attribute cannot be applied to a declaration
attributes.c:126:18: error: expected external declaration
*/
