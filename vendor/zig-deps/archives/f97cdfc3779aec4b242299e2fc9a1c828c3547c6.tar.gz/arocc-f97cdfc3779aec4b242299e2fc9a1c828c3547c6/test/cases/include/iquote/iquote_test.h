#define FOO 42
