void foo(__attribute__((deprecated)) int arg, int arg2 __attribute__((deprecated))) {
    __attribute__((deprecated)) int foo = 1;
    int __attribute__((deprecated)) bar = 2;
    int baz __attribute__((deprecated)) = 3;

    foo;
    bar;
    baz;
    arg;
    arg2;
}

void bar(int __attribute__((deprecated)) arg __attribute__((aligned))) {
    (void) arg;
}

void baz(void) {
    int x[[deprecated]];
    x = 5;
}

struct S {
    int __attribute__((deprecated("foo", "bar"), packed)) p;
};

int deprecated_field(struct S s) {
    (void)__builtin_offsetof(struct S, p);
    return s.p;
}

/** manifest:
syntax
args = -std=c23 -Wno-unused-value

deprecated vars.c:6:5: warning: 'foo' is deprecated [-Wdeprecated-declarations]
deprecated vars.c:2:20: note: 'foo' has been explicitly marked deprecated here
deprecated vars.c:7:5: warning: 'bar' is deprecated [-Wdeprecated-declarations]
deprecated vars.c:3:24: note: 'bar' has been explicitly marked deprecated here
deprecated vars.c:8:5: warning: 'baz' is deprecated [-Wdeprecated-declarations]
deprecated vars.c:4:28: note: 'baz' has been explicitly marked deprecated here
deprecated vars.c:9:5: warning: 'arg' is deprecated [-Wdeprecated-declarations]
deprecated vars.c:1:25: note: 'arg' has been explicitly marked deprecated here
deprecated vars.c:10:5: warning: 'arg2' is deprecated [-Wdeprecated-declarations]
deprecated vars.c:1:71: note: 'arg2' has been explicitly marked deprecated here
deprecated vars.c:14:12: warning: 'arg' is deprecated [-Wdeprecated-declarations]
deprecated vars.c:13:29: note: 'arg' has been explicitly marked deprecated here
deprecated vars.c:19:5: warning: 'x' is deprecated [-Wdeprecated-declarations]
deprecated vars.c:18:12: note: 'x' has been explicitly marked deprecated here
deprecated vars.c:28:14: warning: 'p' is deprecated: foo [-Wdeprecated-declarations]
deprecated vars.c:28:14: note: use 'bar' instead
deprecated vars.c:23:24: note: 'p' has been explicitly marked deprecated here
*/
