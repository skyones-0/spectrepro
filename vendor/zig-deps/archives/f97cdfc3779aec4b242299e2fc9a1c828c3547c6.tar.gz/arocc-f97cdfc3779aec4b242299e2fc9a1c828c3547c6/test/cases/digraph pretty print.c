%:%: %: <%<%> > <::>

/** manifest:
expand
*/
