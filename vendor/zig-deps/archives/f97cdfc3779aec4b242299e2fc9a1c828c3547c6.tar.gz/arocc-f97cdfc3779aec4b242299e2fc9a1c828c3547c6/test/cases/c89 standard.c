void foo(void) {
	int inline = 5;
	int restrict = 10;
	int typeof = 20;
}

/** manifest:
syntax
args = -std=c89
*/
